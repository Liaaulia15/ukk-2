<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Balita extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_balita');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'balita';

        $data['balita'] = $this->Model_balita->getAllbalita();
        if( $this->input->post('keyword') ) {
            $data['balita'] = $this->Model_balita->Caribalita();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('balita/index.php', $data);
        $this->load->view('templates/footer.php');
    }
    
    public function tambah()
    {
        $this->form_validation->set_rules('nama', 'nama', 'trim|required');
        $this->form_validation->set_rules('tgl_lahir', 'tgl_lahir', 'trim|required');
        $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'trim|required');
        $this->form_validation->set_rules('umur', 'umur', 'trim|required');
        $this->form_validation->set_rules('nama_ibu', 'nama_ibu', 'trim|required');
        $this->form_validation->set_rules('nama_ayah', 'nama_ayah', 'trim|required');
        $this->form_validation->set_rules('alamat', 'alamat', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah balita';

            $this->load->view('templates/header.php', $data);
            $this->load->view('balita/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_balita->Tambahbalita();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('balita');
        }
        
    }
    public function ubah($id)
    {
        $this->form_validation->set_rules('nama', 'nama', 'trim|required');
        $this->form_validation->set_rules('tgl_lahir', 'tgl_lahir', 'trim|required');
        $this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'trim|required');
        $this->form_validation->set_rules('umur', 'umur', 'trim|required');
        $this->form_validation->set_rules('nama_ibu', 'nama_ibu', 'trim|required');
        $this->form_validation->set_rules('nama_ayah', 'nama_ayah', 'trim|required');
        $this->form_validation->set_rules('alamat', 'alamat', 'trim|required');


        $data['balita'] = $this->Model_balita->getbalitaById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah balita';

            $this->load->view('templates/header.php', $data);
            $this->load->view('balita/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_balita->Ubahbalita();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('balita');
        }
    } 
     public function hapus($id)
        {
            $this->Model_balita->hapusbalita($id);
            $this->session->set_flashdata('flash', 'Dihapus');
            redirect('balita');
        }
}



   








