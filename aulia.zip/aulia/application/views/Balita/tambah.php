<div class="container">
    <?= form_open_multipart('balita/tambah');?>
        <legend>Tambah Data Balita</legend>
        <div class="mb-3">
            <label for="nama" class="form-label">nama</label>
            <input type="text" class="form-control" id="nama" name="nama" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama'); ?></div>
        </div>
        <div class="mb-3">
            <label for="tgl lahir" class="form-label">tgl lahir</label>
            <input type="date" class="form-control" id="tgl lahir" name="tgl lahir" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('tgl lahir'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="jenis kelamin" class="form-label">jenis kelamin</label>
            <input type="text" class="form-control" id="jenis kelamin" name="jenis kelamin" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('jenis kelamin'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="umur" class="form-label">umur</label>
            <input type="text" class="form-control" id="umur" name="umur" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('umur'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="nama_ibu</" class="form-label">nama ibu</label>
            <input type="text" class="form-control" id="nama_ibu</" name="nama_ibu</" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama_ibu</'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="nama_ayah<" class="form-label">nama_ayah</label>
            <input type="text" class="form-control" id="nama_ayah<" name="nama_ayah<" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('nama_ayah<'); ?></div>
        </div> 
        <div class="mb-3">
            <label for="alamat<" class="form-label">alamat</label>
            <input type="text" class="form-control" id="alamat<" name="alamat<" style="width : 500px;">
            <div class="form-text text-danger"><?= form_error('alamat<'); ?></div>
        </div> 
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>





  























































