<?php
class Model_kader extends CI_model 
{
    public function getAllkader()
    {
        return $query = $this->db->get('kader')->result_array();
    }

    public function Tambahkader()
    {
        $this->load->library('upload', $config);
        $data = [
            "nama" => $this->input->post('nama', true),
            "jabatan" => $this->input->post('jabatan', true),
            "tgl_lahir" => $this->input->post('tgl_lahir', true),
            "alamat" => $this->input->post('alamat', true),
            "no_hp" => $this->input->post('no_hp', true)
            
        ];

        $this->db->insert('kader', $data);

        $this->session->set_flashdata('flash', 'ditambahkan');
    }

    public function Ubahkader()
    {
        $data = [
            "nama" => $this->input->post('nama', true),
            "jabatan" => $this->input->post('jabatan', true),
            "tgl_lahir" => $this->input->post('tgl_lahir', true),
            "alamat" => $this->input->post('alamat', true),
            "no_hp" => $this->input->post('no_hp', true)
            
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('kader', $data);
    }
    
    public function hapuskader($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('kader');
    }
    public function getkaderById($id)
    {
        return $this->db->get_where('kader', ['id' => $id])->row_array();
    }
  
	public function Carikader()
	{
       $keyword = $this->input->post('keyword', true);
       $this->db->like('nama',$keyword);
       return $this->db->get('kader')->result_array();
	}
 }
?>





    